
package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Frame2 extends JFrame implements ActionListener {
    JTextField tf1, tf2, tf4, tf5;
    JPasswordField tf3;
    JLabel userLabel;
    Font myFont;
    Color myColor = Color.WHITE;
    JLabel label1;
    JPanel p;
    JButton JB1, JB2;

    public Frame2() {
        super("Recipe Organizer");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFont = new Font("Cambria", Font.PLAIN, 28);

        p = new JPanel();
        p.setLayout(null);
        p.setBackground(myColor);
        this.add(p);

        label1 = new JLabel();
        label1.setText("User Name");
        label1.setBounds(430, 75, 500, 50);
        p.add(label1);

        tf1 = new JTextField();
        tf1.setBounds(570, 85, 260, 30);
        tf1.setFont(myFont);
        p.add(tf1);

        label1 = new JLabel();
        label1.setText("Email");
        label1.setBounds(430, 110, 500, 50);
        p.add(label1);

        tf2 = new JTextField();
        tf2.setBounds(570, 120, 260, 30);
        p.add(tf2);

        label1 = new JLabel();
        label1.setText("Password");
        label1.setBounds(430, 145, 500, 50);
        p.add(label1);

        tf3 = new JPasswordField();
        tf3.setBounds(570, 155, 260, 30);
        tf3.setEchoChar('*');
        p.add(tf3);

        JB1 = new JButton("Register");
        JB1.setBounds(649, 225, 183, 50);
        JB1.addActionListener(this);
        p.add(JB1);

        JB2 = new JButton("Back");
        JB2.setBounds(449, 225, 183, 50);
        JB2.addActionListener(this);
        p.add(JB2);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == JB1) {
            if (tf1.getText().isEmpty() || tf2.getText().isEmpty() || tf3.getPassword().length == 0) {
                JOptionPane.showMessageDialog(null, "Please fill in all fields");
            } else {
                try {
                    BufferedWriter writer = new BufferedWriter(new FileWriter("registered_users.txt", true));
                    // Save username, email, and password to the file
                    writer.write("Username: " + tf1.getText() + ", Email: " + tf2.getText() + ", Password: " + new String(tf3.getPassword()) + "\n");
                    writer.close();
                    JOptionPane.showMessageDialog(null, "Registration successful!");
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error occurred while saving data.");
                    e.printStackTrace();
                }
                // Commenting out the code for transitioning to the homepage
                // homepage f1 = new homepage();
                // f1.setVisible(true);
                // this.setVisible(false);
            }
        } else if (ae.getSource() == JB2) {
            // Go back to the homepage
            homepage frame = new homepage();
            frame.setVisible(true);
            this.dispose(); // Close the current frame
        }
    }

    public static void main(String[] args) {
        Frame2 frame = new Frame2();
        frame.setVisible(true);
    }
}
