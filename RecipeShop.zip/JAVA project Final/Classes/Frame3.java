
package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Frame3 extends JFrame implements ActionListener {
    JButton JB1, JB2, JB3;
    JLabel label1;
    JPanel p;
    Color myColor = Color.WHITE;

    public Frame3() {
        super("Recipe Organizer");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p = new JPanel();
        p.setLayout(null);
        p.setBackground(myColor);
        this.add(p);

        JB1 = new JButton("Indian");
        JB1.setBounds(549, 225, 183, 50);
        JB1.addActionListener(this);
        p.add(JB1);

        JB2 = new JButton("Bangladeshi");
        JB2.setBounds(549, 325, 183, 50);
        JB2.addActionListener(this);
        p.add(JB2);

        JB3 = new JButton("Chinese");
        JB3.setBounds(549, 425, 183, 50);
        JB3.addActionListener(this);
        p.add(JB3);
    }

    public void actionPerformed(ActionEvent xe) {
        if (xe.getSource() == JB1) {
             Frame4 frame = new Frame4();
             frame.setVisible(true);
            // Code to handle JB1 button click
        } else if (xe.getSource() == JB2) {
            Frame5 frame = new Frame5();
            frame.setVisible(true);

            // Code to handle JB2 button click
        } else if (xe.getSource() == JB3) {
            Frame6 frame = new Frame6();
             frame.setVisible(true);
            // Code to handle JB3 button click
        }
    }

    public static void main(String[] args) {
        Frame3 frame = new Frame3();
        frame.setVisible(true);
    }
}
