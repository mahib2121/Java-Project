package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame10 extends JFrame {
    private JTextArea mainTextArea; // Change JPanel to JTextArea

    public Frame10() {
        setTitle("Text Display Panel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // Initialize a JTextArea instead of JPanel
        mainTextArea = new JTextArea();
        mainTextArea.setBackground(Color.WHITE);
        mainTextArea.setEditable(false); // Set text area as non-editable

        String[] textLines = {
                "Marinate 500g diced chicken with 1 cup yogurt, 1 tbsp ginger-garlic paste, 1 tsp chili powder, 1 tsp turmeric, and salt for 30 mins.",
                "Heat 2 tbsp butter in a pan, add 1 finely chopped onion, sauté until golden, then add 2 tsp tomato paste and cook for 2 mins.",
                "Add 1 tsp garam masala, 1 tsp ground cumin, 1 tsp ground coriander, and cook for another 2 mins."
                // Add more steps as needed
        };

        StringBuilder numberedText = new StringBuilder();
        for (int i = 0; i < textLines.length; i++) {
            numberedText.append((i + 1)).append(". ").append(textLines[i]).append("\n");
        }

        mainTextArea.setText(numberedText.toString()); // Set the formatted text to JTextArea

        add(new JScrollPane(mainTextArea), BorderLayout.CENTER);


        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the current frame (Frame7)
            }
        });


        JButton buyNowButton = new JButton("Buy Now");
        buyNowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Frame18 f = new Frame18();
                f.setVisible(true);
            }
        });


        JPanel buttonPanel = new JPanel();
        buttonPanel.add(backButton);
        buttonPanel.add(buyNowButton);

        add(buttonPanel, BorderLayout.SOUTH);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Frame7 frame = new Frame7();
            frame.setVisible(true);
        });
    }
}
