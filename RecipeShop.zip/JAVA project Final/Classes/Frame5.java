package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Frame5 extends JFrame implements ActionListener {

    JButton JB1, JB2, JB3;
    JLabel label1;
    JPanel p;
    Color myColor = Color.WHITE;

    public Frame5() {
        super("Bangladeshi");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p = new JPanel();
        p.setLayout(null);
        p.setBackground(myColor);
        this.add(p);

        JB1 = new JButton("Kachhi biriyani ");
        JB1.setBounds(649, 225, 183, 50);
        JB1.addActionListener(this);
        p.add(JB1);

        JB2 = new JButton("Comming Soon ");
        JB2.setBounds(649, 325, 183, 50);
        JB2.addActionListener(this);
        p.add(JB2);

        JB3 = new JButton("Coming soon");
        JB3.setBounds(649, 425, 183, 50);
        JB3.addActionListener(this);
        p.add(JB3);



    }
    public void actionPerformed(ActionEvent xb) {
        if (xb.getSource() == JB1) {
            Frame10 frame = new Frame10();
            frame.setVisible(true);
          
        } else if (xb.getSource() == JB2) {

            
            // Code to handle JB2 button click
        } else if (xb.getSource() == JB3) {
            // Code to handle JB3 button click
        }
    }



    

    
}
