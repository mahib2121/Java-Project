package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame18 extends JFrame implements ActionListener {
    JPanel p1;
    JLabel Lab1, Lab2, Lab3;
    JButton JB1;
    Color myColor = Color.WHITE;
    ImageIcon img;

    public Frame18() {

        super("Product Details");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p1 = new JPanel();
        p1.setLayout(null);
        p1.setBackground(myColor);
        this.add(p1);

        // Update the path to your image file
        img = new ImageIcon("BIRIYANI.png");
        JLabel imgLabel = new JLabel(img);
        imgLabel.setBounds(450, 150, 200, 112);
        p1.add(imgLabel);

        Lab1 = new JLabel("Product name: BIRIYANI Masala");
        Lab1.setBounds(120, 115, 160, 70);
        Lab1.setBackground(myColor);
        Lab1.setForeground(Color.BLACK);
        p1.add(Lab1);

        Lab2 = new JLabel(" Net weight: 50 gm  ");
        Lab2.setBounds(120, 150, 160, 30); // Adjusted Y position to avoid overlap
        Lab2.setBackground(myColor);
        Lab2.setForeground(Color.BLACK);
        p1.add(Lab2);

        Lab3 = new JLabel("Price : 100 BDT ");
        Lab3.setBounds(120, 185, 160, 30); // Adjusted Y position to avoid overlap
        Lab3.setBackground(myColor);
        Lab3.setForeground(Color.BLACK);
        p1.add(Lab3);

        JB1 = new JButton("Buy now ");
        JB1.setBounds(649, 225, 183, 50);
        JB1.addActionListener(this);
        p1.add(JB1);

        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent xb) {
        if (xb.getSource() == JB1) {
            PaymentFrame frame = new PaymentFrame();
            frame.setVisible(true);
            

        }
    }
}





