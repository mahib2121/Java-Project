package Classes;
import javax.swing.*;
import java.awt.*;

public class Frame8 extends JFrame {
    private JTextArea mainTextArea; // Change JPanel to JTextArea

    public Frame8() {
        setTitle("Text Display Panel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 400);

        // Initialize a JTextArea instead of JPanel
        mainTextArea = new JTextArea();
        mainTextArea.setBackground(Color.WHITE);
        mainTextArea.setEditable(false); // Set text area as non-editable

        String[] textLines = {"Mix 500g chicken pieces with 1 cup yogurt, 1 tbsp ginger-garlic paste, 1 tsp chili powder, 1 tsp turmeric, 1 tsp garam masala, and salt."
         ,"Marinate for at least 2 hours or overnight in the refrigerator.","Preheat the oven to 425°F (220°C) and thread marinated chicken onto skewers.","4.Place the skewers on a baking tray and bake for 20-25 mins, turning halfway through until chicken is cooked and slightly charred.",
        "Serve hot with sliced onions, lemon wedges, and mint-coriander chutney."
        
        };

        StringBuilder numberedText = new StringBuilder();
        for (int i = 0; i < textLines.length; i++) {
            numberedText.append((i + 1)).append(". ").append(textLines[i]).append("\n");
        }

        mainTextArea.setText(numberedText.toString()); // Set the formatted text to JTextArea

        add(new JScrollPane(mainTextArea), BorderLayout.CENTER);
    }

   
}

