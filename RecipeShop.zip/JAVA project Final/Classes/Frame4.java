package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Frame4 extends JFrame implements ActionListener  {
    JButton JB1, JB2, JB3;
    JLabel label1;
    JPanel p;
    Color myColor = Color.WHITE;

    public Frame4() {
        super("Indian");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p = new JPanel();
        p.setLayout(null);
        p.setBackground(myColor);
        this.add(p);

        JB1 = new JButton("Butter Chicken");
        JB1.setBounds(649, 225, 183, 50);
        JB1.addActionListener(this);
        p.add(JB1);

        JB2 = new JButton("Tandoori");
        JB2.setBounds(649, 325, 183, 50);
        JB2.addActionListener(this);
        p.add(JB2);

        JB3 = new JButton("Tikka");
        JB3.setBounds(649, 425, 183, 50);
        JB3.addActionListener(this);
        p.add(JB3);



    }
    public void actionPerformed(ActionEvent xb) {
        if (xb.getSource() == JB1) {
            Frame7 frame = new Frame7();
             frame.setVisible(true);
            // Code to handle JB1 button click
        } else if (xb.getSource() == JB2) {
            Frame8 frame = new Frame8();
             frame.setVisible(true);
            // Code to handle JB2 button click
        } else if (xb.getSource() == JB3) {
            // Code to handle JB3 button click
        }
    }


    
}
