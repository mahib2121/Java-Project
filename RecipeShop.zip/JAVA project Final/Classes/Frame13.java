package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame13 extends JFrame {

    private JTextArea mainTextArea;

    public Frame13() {
        setTitle("Chow Mein Recipe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        mainTextArea = new JTextArea();
        mainTextArea.setBackground(Color.WHITE);
        mainTextArea.setEditable(false);

        String[] textLines = {
            "Ingredients: Gather 8 oz. of chow mein noodles, 2 tbsp. vegetable oil, 2 cloves of minced garlic, 1 diced onion, 2 cups of sliced vegetables (like bell peppers, carrots, and cabbage), 1 cup of sliced protein (chicken, beef, tofu, or shrimp), 3 tbsp. soy sauce, 2 tbsp. oyster sauce, and 1 tsp. sesame oil.",
            "Boil Noodles: Cook chow mein noodles according to package instructions, then drain and set aside.",
            "Prepare Sauce: Mix soy sauce, oyster sauce, and sesame oil in a small bowl, set aside.",
            "Sauté: Heat vegetable oil in a large skillet or wok over high heat, add minced garlic, and diced onion, stir-fry for a minute.",
            "Add Protein & Vegetables: Add your choice of protein, stir-fry until cooked through, then toss in sliced vegetables, cooking until they're slightly tender but still crisp.",
            "Combine Noodles & Sauce: Add the cooked noodles to the skillet or wok with the prepared sauce. Toss everything together until the noodles are evenly coated.",
            "Enjoy: Serve the Chow Mein hot as a delicious meal or as a side dish"
        };

        StringBuilder numberedText = new StringBuilder();
        for (int i = 0; i < textLines.length; i++) {
            numberedText.append((i + 1)).append(". ").append(textLines[i]).append("\n");
        }

        mainTextArea.setText(numberedText.toString());

        add(new JScrollPane(mainTextArea), BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        JButton buyNowButton = new JButton("Buy Now");
        buyNowButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Replace Frame17 with appropriate functionality or call the desired action
                 Frame19 f = new Frame19();
                 f.setVisible(true);
                
                // For example, showing a dialog for Buy Now action
               // JOptionPane.showMessageDialog(Frame13.this, "Buy Now clicked!");
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(backButton);
        buttonPanel.add(buyNowButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Frame13 frame = new Frame13();
            frame.setVisible(true);
        });
    }
}
