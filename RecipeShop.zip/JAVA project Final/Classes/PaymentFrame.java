package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class PaymentFrame extends JFrame {

    private JComboBox<String> cardTypeComboBox;
    private JTextField cardNumberField;
    private JTextField expiryDateField;
    private JTextField cvvField;

    public PaymentFrame() {
        setTitle("Payment Frame");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();

        setVisible(true);
        setResizable(false);
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2, 10, 10));
        panel.setBackground(Color.CYAN);

        String[] cardTypes = {"MasterCard", "Visa"};
        cardTypeComboBox = new JComboBox<>(cardTypes);

        cardNumberField = new JTextField();
        expiryDateField = new JTextField();
        cvvField = new JTextField();

        panel.add(new JLabel("Card Type:"));
        panel.add(cardTypeComboBox);
        panel.add(new JLabel("Card Number:"));
        panel.add(cardNumberField);
        panel.add(new JLabel("Payment Amount:"));
        panel.add(expiryDateField);
        panel.add(new JLabel("CVV:"));
        panel.add(cvvField);

        JButton payButton = new JButton("Pay Now");
        JButton backButton = new JButton("Back");
        payButton.addActionListener(new ActionListener() {
  
            public void actionPerformed(ActionEvent e) {
                processPayment();
            }
        });

        //backButton.addActionListener(new ActionListener() {
           
          //  public void actionPerformed(ActionEvent e) {
            //    dispose();
              //  new Dashboard();
           // }
        //});

        panel.add(payButton);
        panel.add(backButton);

        add(panel);
    }

    private void processPayment() {
        // Display payment success message
        JOptionPane.showMessageDialog(this, "Payment Successful!", "Payment Status", JOptionPane.INFORMATION_MESSAGE);

        // Save payment information
        savePayment();
    }

    private void savePayment() {
        try (FileWriter fileWriter = new FileWriter("./PaymentData.txt", true)) {
            // Append payment information to the file
            String cardType = (String) cardTypeComboBox.getSelectedItem();
            String cardNumber = cardNumberField.getText();
            String expiryDate = expiryDateField.getText();
            String cvv = cvvField.getText();

            fileWriter.write(cardType + "\t" + cardNumber + "\t" + expiryDate + "\t" + cvv + "\n");
            fileWriter.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
}
