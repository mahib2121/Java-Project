package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;



public class Frame6 extends JFrame implements ActionListener {
    JButton JB1, JB2, JB3;
    JLabel label1;
    JPanel p;
    Color myColor = Color.WHITE;

    public Frame6() {
        super("Chinese");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        p = new JPanel();
        p.setLayout(null);
        p.setBackground(myColor);
        this.add(p);

        JB1 = new JButton("Chow Mein ");
        JB1.setBounds(649, 225, 183, 50);
        JB1.addActionListener(this);
        p.add(JB1);

        JB2 = new JButton("Spring Roll");
        JB2.setBounds(649, 325, 183, 50);
        JB2.addActionListener(this);
        p.add(JB2);

        JB3 = new JButton("Chiken Fried Rice");
        JB3.setBounds(649, 425, 183, 50);
        JB3.addActionListener(this);
        p.add(JB3);

    }
    public void actionPerformed(ActionEvent xb) {
        if (xb.getSource() == JB1) {
            Frame13 f = new Frame13();
            f.setVisible(true);
            // Code to handle JB1 button click
        } else if (xb.getSource() == JB2) {
            // Code to handle JB2 button click
        } else if (xb.getSource() == JB3) {
            // Code to handle JB3 button click
        }
    }
    
}
