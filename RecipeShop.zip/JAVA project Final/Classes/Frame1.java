
package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Frame1 extends JFrame implements ActionListener {
    JTextField userTF;
    JPanel panel;
    JLabel userLabel, passLabel;
    JButton logiButton;
    JPasswordField passPFi;
    Font myFont;
    Color myColor = Color.WHITE;

    public Frame1() {
        super("Recipe Organizer");
        this.setSize(700, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFont = new Font("Cambria", Font.PLAIN, 28);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(myColor);
        this.add(panel);

        userLabel = new JLabel("Username");
        userLabel.setBounds(120, 115, 160, 30);
        userLabel.setBackground(myColor);
        userLabel.setForeground(Color.BLACK);
        userLabel.setFont(myFont);
        panel.add(userLabel);

        passLabel = new JLabel("Password");
        passLabel.setBounds(150, 190, 160, 30);
        passLabel.setBackground(myColor);
        passLabel.setFont(myFont);
        panel.add(passLabel);

        userTF = new JTextField();
        userTF.setBounds(280, 115, 160, 30);
        userTF.setBackground(myColor);
        userTF.setFont(myFont);
        panel.add(userTF);

        passPFi = new JPasswordField();
        passPFi.setBounds(290, 190, 160, 30);
        passPFi.setBackground(myColor);
        passPFi.setFont(myFont);
        panel.add(passPFi);

        logiButton = new JButton("LOGIN");
        logiButton.setBounds(300, 225, 80, 30);
        logiButton.setBackground(Color.RED);
        logiButton.addActionListener(this);
        panel.add(logiButton);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == logiButton) {
            String username = userTF.getText();
            String password = new String(passPFi.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter both username and password.");
            } else {
                boolean loggedIn = false;

                try (BufferedReader reader = new BufferedReader(new FileReader("registered_users.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.contains("Username: " + username) && line.contains("Password: " + password)) {
                            loggedIn = true;
                            break;
                        }
                    }
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(null, "Error reading user data.");
                    ex.printStackTrace();
                }

                if (loggedIn) {
                    JOptionPane.showMessageDialog(null, "Login successful!");
                    // Proceed to the next frame or homepage
                    Frame3 f = new Frame3();
                    f.setVisible(true);
                    this.dispose(); // Close the current frame
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password!");
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Frame1 frame = new Frame1();
            frame.setVisible(true);
        });
    }
}
