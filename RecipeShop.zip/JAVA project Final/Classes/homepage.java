package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class homepage extends JFrame implements ActionListener {
    JButton logiButton,resg,admin;
    Font myFont;
    JPanel panel;
    Color myColor=Color.WHITE;
    JLabel userLabel;

    public homepage(){
        super("Recipe Organizer");
        this.setSize(1200,700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFont = new Font("Cambria", Font.PLAIN, 28);

        panel=new JPanel();
        panel.setLayout(null);
        panel.setBackground(myColor);
        this.add(panel);

        logiButton = new JButton(" Login ");
        logiButton.setBounds(300, 225, 80, 30);
        logiButton.setBackground(Color.WHITE);
        logiButton.addActionListener(this);
        panel.add(logiButton);

        resg = new JButton("Register");
        resg.setBounds(450, 225, 100, 30);
        resg.setBackground(myColor);
        resg.addActionListener(this);
        panel.add(resg);

        userLabel = new JLabel("Welcome to RECUIPE SHOP BD ");
        userLabel.setBounds(50, 20, 600, 160);
        userLabel.setBackground(myColor);
        userLabel.setForeground(Color.BLACK);
        userLabel.setFont(myFont);
        panel.add(userLabel);



    }

    public void actionPerformed(ActionEvent ab){
        if (ab.getSource() == logiButton) {
            Frame1 f = new Frame1(); // Instantiate Frame3
            f.setVisible(true);
        }
        else if (ab.getSource()==resg){
            Frame2 f = new Frame2();
            f.setVisible(true);

        }


    }


    
}
